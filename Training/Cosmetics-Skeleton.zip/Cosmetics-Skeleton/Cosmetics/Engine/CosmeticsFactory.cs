﻿namespace Cosmetics.Engine
{
    using System.Collections.Generic;

    using Cosmetics.Common;
    using Cosmetics.Contracts;
    using Cosmetics.Products;

    public class CosmeticsFactory : ICosmeticsFactory
    {
        private const string InvalidCategoryLenght = "Category name must be between {0} and {1} symbols long!";
        private const string InvalidProductNameLenght = "Product name must be between {0} and {1} symbols long!";
        private const string InvalidProductBrandLenght = "Product brand must be between {0} and {1} symbols long!";

        public ICategory CreateCategory(string name)
        {
            Validator.CheckIfStringLengthIsValid(name, 15, 2, InvalidCategoryLenght);
            var category = new Category(name);
            return category;
        }

        public IShampoo CreateShampoo(string name, string brand, decimal price, GenderType gender, uint milliliters, UsageType usage)
        {
            Validator.CheckIfStringLengthIsValid(name, 10, 3, InvalidProductNameLenght);
            Validator.CheckIfStringLengthIsValid(brand, 10, 2, InvalidProductBrandLenght);

            var shampoo = new Shampoo(name,brand,price,gender,milliliters,usage);
            return shampoo;
        }

        public IToothpaste CreateToothpaste(string name, string brand, decimal price, GenderType gender, IList<string> ingredients)
        {
            Validator.CheckIfStringLengthIsValid(name, 10, 3, InvalidProductNameLenght);
            Validator.CheckIfStringLengthIsValid(brand, 10, 2, InvalidProductBrandLenght);

            var toothpaste = new Toothpaste(name,brand,price,gender,ingredients);
            return toothpaste;
        }

        public IShoppingCart ShoppingCart()
        {
            var shoppingCart = new ShoppingCart();
            return shoppingCart;
        }
    }
}
