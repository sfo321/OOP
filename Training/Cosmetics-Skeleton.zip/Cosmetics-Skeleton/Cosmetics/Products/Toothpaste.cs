﻿using System;

namespace Cosmetics.Products
{
    using System.Collections;
    using System.Collections.Generic;
    using System.Text;
    using Cosmetics.Common;
    using Cosmetics.Contracts;

    public class Toothpaste : Product, IToothpaste
    {
        private readonly IList<string> ingredients;
        // Missing validation !!!

        public Toothpaste(string name, string brand, decimal price, GenderType gender, IList<string> ingredients) : base(name, brand, price, gender)
        {
            this.ingredients = ingredients;
        }

        public string Ingredients {
            get { return String.Join(", ", this.ingredients); }
        }

        public override string Print()
        {
            // Ingredient must be collection !!!

            StringBuilder print = new StringBuilder();

            print.AppendLine(base.Print());
            print.AppendFormat("  * Ingredients: {0}", this.Ingredients);


            return print.ToString().TrimEnd();
        }
    }
}