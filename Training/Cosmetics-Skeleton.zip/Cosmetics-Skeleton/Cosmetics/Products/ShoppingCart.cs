﻿using System.Collections.Generic;

namespace Cosmetics.Products
{
    using Cosmetics.Contracts;

    public class ShoppingCart : IShoppingCart
    {
        private ICollection<IProduct> products;
        private decimal totalPrice;

        public ShoppingCart()
        {
           this. products = new List<IProduct>();
        }

        public void AddProduct(IProduct product)
        {
            this.products.Add(product);
        }

        public void RemoveProduct(IProduct product)
        {
            if (this.products.Contains(product))
            {
                this.products.Remove(product);
            }
        }

        public bool ContainsProduct(IProduct product)
        {
            bool isContaints = products.Contains(product);

            return isContaints;
        }

        public decimal TotalPrice()
        {
            this.totalPrice = 0;

            foreach (IProduct product in products)
            {
                this.totalPrice += product.Price;
            }

            return this.totalPrice;
        }
    }
}