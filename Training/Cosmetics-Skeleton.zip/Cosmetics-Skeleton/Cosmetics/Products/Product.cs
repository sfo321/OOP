﻿
using System.Text;

namespace Cosmetics.Products
{
    using Cosmetics.Common;
    using Cosmetics.Contracts;

    public class Product : IProduct
    {
        private readonly string name;
        private readonly string brand;
        protected decimal price;
        private readonly GenderType gender;

        // Missing validation !!!

        public Product(string name, string brand, decimal price, GenderType gender)
        {
            this.name = name;
            this.brand = brand;
            this.price = price;
            this.gender = gender;

        }

        public string Name {
            get { return this.name; }
        }
        public string Brand
        {
            get { return this.brand; }
        }
        public decimal Price
        {
            get { return this.price; }
            
        }
        public GenderType Gender
        {
            get { return this.gender; }
        }




        public virtual string Print()
        {
            StringBuilder print = new StringBuilder();

            print.AppendFormat("- {0} - {1}:\n", this.Brand, this.Name);
            print.AppendFormat("  * Price: ${0:F2}\n", this.Price);
            print.AppendFormat("  * For gender: {0}", this.Gender);

            return print.ToString().TrimEnd();
        }
    }
}

//- Nivea - Cool:
//  * Price: $250.00
//  * For gender: Men
//  * Quantity: 500 ml
//  * Usage: EveryDay