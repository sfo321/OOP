﻿
using System.Dynamic;
using System.Text;

namespace Cosmetics.Products
{
    using Cosmetics.Common;
    using Cosmetics.Contracts;

    public class Shampoo : Product, IShampoo
    {
        private readonly uint milliliters;
        private readonly UsageType usage;


        // Missing validation !!!

        public Shampoo(string name, string brand, decimal price, GenderType gender, uint milliliters, UsageType usage) : base(name, brand, price, gender)
        {
            this.milliliters = milliliters;
            this.usage = usage;

            // Must works !!!
            base.price = price * milliliters;
        }

        public uint Milliliters
        {
            get { return this.milliliters; }
        }
        public UsageType Usage
        {
            get { return this.usage; }
        }

        public override string Print()
        {
            StringBuilder print = new StringBuilder();

            print.AppendLine(base.Print());
            print.AppendFormat("  * Quantity: {0} ml\n", this.Milliliters);
            print.AppendFormat("  * Usage: {0}", this.Usage);

            return print.ToString().TrimEnd();
        }
    }
}

  //* Quantity: 500 ml
  //* Usage: EveryDay