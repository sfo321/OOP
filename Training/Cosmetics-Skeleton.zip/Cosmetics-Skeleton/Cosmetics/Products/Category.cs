﻿
namespace Cosmetics.Products
{

    using System.Collections.Generic;
    using System.Text;

    using System.Linq; 
    using Cosmetics.Contracts;

    public class Category : ICategory
    {
        private readonly string name;
        ICollection<IProduct> products;

        public Category(string name)
        {
            this.name = name;
            products = new List<IProduct>();
        }

        public string Name {
            get { return this.name; }
        }

        public void AddCosmetics(IProduct cosmetics)
        {
            products.Add(cosmetics);
        }

        // Must see is it work !
        // Validation is product containts removing objects

        public void RemoveCosmetics(IProduct cosmetics)
        {
            products.Remove(cosmetics);
        }

        public string Print()
        {
            StringBuilder print = new StringBuilder();

            if (products.Count == 1)
            {
                print.AppendFormat("{0} category - {1} product in total\n", this.Name, this.products.Count);

                foreach (IProduct product in products.OrderBy(c => c.Brand).ThenByDescending(d => d.Price))
                {
                    print.AppendLine(product.Print());
                }

            }
            else { 
                print.AppendFormat("{0} category - {1} products in total\n",this.Name,this.products.Count);

                foreach (IProduct product in products.OrderBy(c => c.Brand).ThenByDescending(d => d.Price))
                {
                    print.AppendLine(product.Print());
                }
            }   

        return print.ToString().TrimEnd();    
        }
    }
}

//ForMale category - 1 product in total